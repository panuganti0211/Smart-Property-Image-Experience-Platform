import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { MapPin, BedDouble, Sparkles } from "lucide-react";
import { fetchProperties } from "../api/propertyApi";
import { Input } from "../components/ui/input";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";

export default function ListingPage() {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [location, setLocation] = useState("");

  useEffect(() => {
    let mounted = true;
    async function load() {
      setLoading(true);
      setError("");
      try {
        const data = await fetchProperties({ location, page: 1, limit: 12 });
        if (mounted) setProperties(data.items || []);
      } catch {
        if (mounted) setError("Unable to load properties now. Please try again.");
      } finally {
        if (mounted) setLoading(false);
      }
    }
    load();
    return () => {
      mounted = false;
    };
  }, [location]);

  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-border bg-card p-6">
        <h1 className="text-3xl font-semibold">Luxury Properties</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Discover premium homes powered by AI-driven image insights.
        </p>
        <div className="mt-4">
          <Input
            placeholder="Filter by location..."
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
        </div>
      </section>

      {loading && (
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, idx) => (
            <div key={idx} className="h-72 animate-pulse rounded-xl bg-neutral-900" />
          ))}
        </div>
      )}

      {!loading && error && (
        <Card className="p-5 text-sm text-red-300">{error}</Card>
      )}

      {!loading && !error && properties.length === 0 && (
        <Card className="p-5 text-sm text-muted-foreground">
          No properties found for the applied filters.
        </Card>
      )}

      {!loading && !error && properties.length > 0 && (
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {properties.map((property) => (
            <Link key={property._id} to={`/properties/${property._id}`}>
              <Card className="group overflow-hidden transition-transform duration-300 hover:-translate-y-1">
                <div className="relative h-56">
                  <img
                    src={
                      property.coverImageUrl ||
                      property.images?.[0]?.url ||
                      "https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6?auto=format&fit=crop&w=1200&q=80"
                    }
                    alt={property.title}
                    className="h-full w-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/65 to-transparent" />
                  <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between">
                    <p className="text-xl font-semibold">${property.price?.toLocaleString()}</p>
                    <Badge>{property.analysisStatus}</Badge>
                  </div>
                </div>
                <div className="space-y-2 p-4">
                  <h2 className="line-clamp-1 text-lg font-medium">{property.title}</h2>
                  <p className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" /> {property.location}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {property.tags?.slice(0, 3).map((tag) => (
                      <Badge key={tag}>{tag}</Badge>
                    ))}
                    {!property.tags?.length && (
                      <Badge className="gap-1">
                        <Sparkles className="h-3 w-3" />
                        AI tags pending
                      </Badge>
                    )}
                  </div>
                  <p className="flex items-center gap-2 text-xs text-muted-foreground">
                    <BedDouble className="h-3.5 w-3.5" />
                    {property.images?.length || 0} images
                  </p>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
