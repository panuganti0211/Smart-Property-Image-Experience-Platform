import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { fetchPropertyById } from "../api/propertyApi";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";

export default function PropertyDetailPage() {
  const { id } = useParams();
  const [property, setProperty] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let mounted = true;
    let pollTimer = null;

    async function load(isInitial = false) {
      if (isInitial) setLoading(true);
      setError("");
      try {
        const data = await fetchPropertyById(id);
        if (!mounted) return;
        setProperty(data);
        if (data.analysisStatus === "pending") {
          pollTimer = setTimeout(() => {
            load(false);
          }, 5000);
        }
      } catch {
        if (mounted) setError("Failed to load this property.");
      } finally {
        if (mounted && isInitial) setLoading(false);
      }
    }

    load(true);
    return () => {
      mounted = false;
      if (pollTimer) clearTimeout(pollTimer);
    };
  }, [id]);

  if (loading) return <div className="h-80 animate-pulse rounded-xl bg-neutral-900" />;
  if (error) return <Card className="p-5 text-red-300">{error}</Card>;
  if (!property) return <Card className="p-5">Property not found.</Card>;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <img
            src={property.coverImageUrl || property.images?.[0]?.url}
            alt={property.title}
            className="h-[420px] w-full rounded-xl object-cover"
          />
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
            {property.images?.map((image) => (
              <img
                key={image._id}
                src={image.url}
                alt={property.title}
                className="h-28 w-full rounded-lg object-cover"
              />
            ))}
          </div>
        </div>

        <Card className="h-fit space-y-4 p-5">
          <h1 className="text-2xl font-semibold">{property.title}</h1>
          <p className="text-xl text-primary">${property.price?.toLocaleString()}</p>
          <p className="text-sm text-muted-foreground">{property.location}</p>
          <div className="flex flex-wrap gap-2">
            {(property.tags || []).map((tag) => (
              <Badge key={tag}>{tag}</Badge>
            ))}
          </div>
          <div>
            <h2 className="mb-2 text-sm font-medium text-muted-foreground">AI Description</h2>
            <p className="text-sm leading-6">
              {property.aiDescription || "AI analysis in progress. Please refresh in a moment."}
            </p>
            {property.analysisStatus === "pending" && (
              <p className="mt-2 text-xs text-amber-300">Image analysis is running. Auto-refreshing...</p>
            )}
          </div>
        </Card>
      </div>

      <Card className="space-y-4 p-5">
        <h2 className="text-lg font-medium">Image Insights</h2>
        {!property.images?.length && (
          <p className="text-sm text-muted-foreground">No images available for insights.</p>
        )}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {property.images?.map((image) => (
            <div key={image._id} className="rounded-lg border border-border p-4">
              <p className="text-sm">
                <span className="text-muted-foreground">Room:</span>{" "}
                {property.analysisStatus === "pending" ? "pending" : image.roomType || "unknown"}
              </p>
              <p className="mt-1 text-sm">
                <span className="text-muted-foreground">Quality:</span>{" "}
                {property.analysisStatus === "pending" ? "--" : image.qualityScore || 0}/100
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {(property.analysisStatus === "pending"
                  ? []
                  : image.features || image.keyFeatures || []
                ).map((feature) => (
                  <Badge key={feature}>{feature}</Badge>
                ))}
              </div>
              <ul className="mt-3 list-disc space-y-1 pl-4 text-xs text-muted-foreground">
                {(property.analysisStatus === "pending"
                  ? []
                  : image.suggestions || image.improvementTips || []
                ).map((tip) => (
                  <li key={tip}>{tip}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
