import { useMemo, useState } from "react";
import { ImagePlus } from "lucide-react";
import { createProperty, uploadImages } from "../api/propertyApi";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Input } from "../components/ui/input";

export default function AddPropertyPage() {
  const [form, setForm] = useState({ title: "", price: "", location: "" });
  const [files, setFiles] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const previews = useMemo(() => files.map((file) => URL.createObjectURL(file)), [files]);

  async function onSubmit(event) {
    console.log("On submit",files);

    event.preventDefault();
    setSubmitting(true);
    setError("");
    setMessage("");
    try {
      const property = await createProperty({
        title: form.title,
        price: Number(form.price),
        location: form.location,
      });
      if (files.length) {
        await uploadImages(property._id, files);
        console.log("Images uploaded",files);
      }
      setMessage("Property created. AI image analysis is running asynchronously.");
      setForm({ title: "", price: "", location: "" });
      setFiles([]);
    } catch (err) {
      const apiMessage = err?.response?.data?.message;
      setError(apiMessage || "Unable to save the property. Please verify fields and retry.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Card className="mx-auto max-w-3xl space-y-5 p-6">
      <h1 className="text-2xl font-semibold">Add New Property</h1>
      <form onSubmit={onSubmit} className="space-y-4">
        <Input
          required
          placeholder="Title"
          value={form.title}
          onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))}
        />
        <Input
          required
          type="number"
          placeholder="Price"
          value={form.price}
          onChange={(e) => setForm((p) => ({ ...p, price: e.target.value }))}
        />
        <Input
          required
          placeholder="Location"
          value={form.location}
          onChange={(e) => setForm((p) => ({ ...p, location: e.target.value }))}
        />

        <label className="block rounded-lg border border-dashed border-border p-6 text-center">
          <ImagePlus className="mx-auto mb-2 h-6 w-6 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">Upload 1-5 images</p>
          <input
            type="file"
            accept="image/*"
            multiple
            className="mt-2"
            onChange={(e) => setFiles(Array.from(e.target.files || []).slice(0, 5))}
          />
        </label>

        {!!previews.length && (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
            {previews.map((url) => (
              <img key={url} src={url} alt="preview" className="h-24 w-full rounded-md object-cover" />
            ))}
          </div>
        )}

        <Button disabled={submitting} className="w-full">
          {submitting ? "Saving..." : "Create Property"}
        </Button>
      </form>

      {message && <p className="text-sm text-emerald-300">{message}</p>}
      {error && <p className="text-sm text-red-300">{error}</p>}
    </Card>
  );
}
